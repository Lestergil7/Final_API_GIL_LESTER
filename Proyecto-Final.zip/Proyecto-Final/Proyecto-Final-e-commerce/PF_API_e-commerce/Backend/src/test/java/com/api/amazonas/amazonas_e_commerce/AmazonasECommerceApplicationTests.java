package com.api.amazonas.amazonas_e_commerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmazonasECommerceApplicationTests {

	@Test
	void contextLoads() {
	}

}
