package com.api.amazonas.amazonas_e_commerce.service;

import com.api.amazonas.amazonas_e_commerce.dto.CuponRequestDTO;
import com.api.amazonas.amazonas_e_commerce.dto.CuponResponseDTO;
import java.util.List;

import com.api.amazonas.amazonas_e_commerce.dto.UsuarioCuponResponseDTO;
import java.util.List;

public interface CuponService {
    List<CuponResponseDTO> listarCupones();
    CuponResponseDTO obtenerCuponPorId(Long id);
    CuponResponseDTO crearCupon(CuponRequestDTO cuponRequestDTO);
    CuponResponseDTO actualizarCupon(Long id, CuponRequestDTO cuponRequestDTO);
    void eliminarCupon(Long id);

    // Nuevos casos de uso
    void asignarCuponAUsuario(Long cuponId, String usuarioId);
    List<UsuarioCuponResponseDTO> listarUsuariosPorCupon(Long cuponId);
}
