package com.api.amazonas.amazonas_e_commerce.exception;

public class CuponNoEncontradoException extends RuntimeException {
    public CuponNoEncontradoException(String mensaje) {
        super(mensaje);
    }
}
