package com.api.amazonas.amazonas_e_commerce.repository;

import com.api.amazonas.amazonas_e_commerce.model.Cupon;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface CuponRepository extends JpaRepository<Cupon, Long> {
    Optional<Cupon> findByNombre(String nombre);
    boolean existsByNombre(String nombre);
}
