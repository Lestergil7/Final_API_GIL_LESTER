package com.api.amazonas.amazonas_e_commerce.controller;

import com.api.amazonas.amazonas_e_commerce.dto.CuponRequestDTO;
import com.api.amazonas.amazonas_e_commerce.dto.CuponResponseDTO;
import com.api.amazonas.amazonas_e_commerce.service.CuponService;
import com.api.amazonas.amazonas_e_commerce.dto.UsuarioCuponResponseDTO;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/cupones")
public class CuponController {
    @Autowired
    private CuponService cuponService;

    @GetMapping
    public List<CuponResponseDTO> listarCupones() {
        return cuponService.listarCupones();
    }

    @GetMapping("/{id}")
    public CuponResponseDTO obtenerCuponPorId(@PathVariable Long id) {
        return cuponService.obtenerCuponPorId(id);
    }

    @PostMapping
    public ResponseEntity<CuponResponseDTO> crearCupon(@Valid @RequestBody CuponRequestDTO cuponRequestDTO) {
        return ResponseEntity.ok(cuponService.crearCupon(cuponRequestDTO));
    }

    @PutMapping("/{id}")
    public CuponResponseDTO actualizarCupon(@PathVariable Long id, @Valid @RequestBody CuponRequestDTO cuponRequestDTO) {
        return cuponService.actualizarCupon(id, cuponRequestDTO);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarCupon(@PathVariable Long id) {
        cuponService.eliminarCupon(id);
        return ResponseEntity.noContent().build();
    }

    // Asignar un cupón a un usuario
    @PostMapping("/{id}/usuarios")
    public ResponseEntity<Void> asignarCuponAUsuario(@PathVariable Long id, @RequestParam String usuarioId) {
        cuponService.asignarCuponAUsuario(id, usuarioId);
        return ResponseEntity.ok().build();
    }

    // Listar los usuarios que tienen un cupón
    @GetMapping("/{id}/usuarios")
    public List<UsuarioCuponResponseDTO> listarUsuariosPorCupon(@PathVariable Long id) {
        return cuponService.listarUsuariosPorCupon(id);
    }
}
