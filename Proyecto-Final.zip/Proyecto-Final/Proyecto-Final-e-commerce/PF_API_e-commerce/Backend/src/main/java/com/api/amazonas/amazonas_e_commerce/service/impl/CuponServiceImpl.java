package com.api.amazonas.amazonas_e_commerce.service.impl;

import com.api.amazonas.amazonas_e_commerce.dto.CuponRequestDTO;
import com.api.amazonas.amazonas_e_commerce.dto.CuponResponseDTO;
import com.api.amazonas.amazonas_e_commerce.exception.CuponNoEncontradoException;
import com.api.amazonas.amazonas_e_commerce.model.Cupon;
import com.api.amazonas.amazonas_e_commerce.repository.CuponRepository;
import com.api.amazonas.amazonas_e_commerce.service.CuponService;
import com.api.amazonas.amazonas_e_commerce.dto.UsuarioCuponResponseDTO;
import com.api.amazonas.amazonas_e_commerce.model.Usuario;
import com.api.amazonas.amazonas_e_commerce.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CuponServiceImpl implements CuponService {
    @Autowired
    private CuponRepository cuponRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    private CuponResponseDTO mapToDTO(Cupon cupon) {
        CuponResponseDTO dto = new CuponResponseDTO();
        dto.setId(cupon.getId());
        dto.setNombre(cupon.getNombre());
        dto.setDescripcion(cupon.getDescripcion());
        return dto;
    }

    @Override
    public void asignarCuponAUsuario(Long cuponId, String usuarioId) {
        Cupon cupon = cuponRepository.findById(cuponId)
                .orElseThrow(() -> new CuponNoEncontradoException("Cupón no encontrado"));
        Usuario usuario = usuarioRepository.findById(usuarioId)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
        usuario.getCupones().add(cupon);
        cupon.getUsuarios().add(usuario);
        usuarioRepository.save(usuario);
        cuponRepository.save(cupon);
    }

    @Override
    public List<UsuarioCuponResponseDTO> listarUsuariosPorCupon(Long cuponId) {
        Cupon cupon = cuponRepository.findById(cuponId)
                .orElseThrow(() -> new CuponNoEncontradoException("Cupón no encontrado"));
        return cupon.getUsuarios().stream().map(usuario -> {
            UsuarioCuponResponseDTO dto = new UsuarioCuponResponseDTO();
            dto.setId(usuario.getId());
            dto.setUsername(usuario.getUsername());
            dto.setEmail(usuario.getEmail());
            dto.setNombre(usuario.getNombre());
            dto.setApellido(usuario.getApellido());
            return dto;
        }).collect(java.util.stream.Collectors.toList());
    }

    @Override
    public List<CuponResponseDTO> listarCupones() {
        return cuponRepository.findAll().stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    @Override
    public CuponResponseDTO obtenerCuponPorId(Long id) {
        Cupon cupon = cuponRepository.findById(id).orElseThrow(() -> new CuponNoEncontradoException("Cupón no encontrado"));
        return mapToDTO(cupon);
    }

    @Override
    public CuponResponseDTO crearCupon(CuponRequestDTO cuponRequestDTO) {
        if (cuponRepository.existsByNombre(cuponRequestDTO.getNombre())) {
            throw new RuntimeException("El nombre del cupón ya existe");
        }
        Cupon cupon = new Cupon();
        cupon.setNombre(cuponRequestDTO.getNombre());
        cupon.setDescripcion(cuponRequestDTO.getDescripcion());
        cupon = cuponRepository.save(cupon);
        return mapToDTO(cupon);
    }

    @Override
    public CuponResponseDTO actualizarCupon(Long id, CuponRequestDTO cuponRequestDTO) {
        Cupon cupon = cuponRepository.findById(id).orElseThrow(() -> new CuponNoEncontradoException("Cupón no encontrado"));
        cupon.setNombre(cuponRequestDTO.getNombre());
        cupon.setDescripcion(cuponRequestDTO.getDescripcion());
        cupon = cuponRepository.save(cupon);
        return mapToDTO(cupon);
    }

    @Override
    public void eliminarCupon(Long id) {
        if (!cuponRepository.existsById(id)) {
            throw new CuponNoEncontradoException("Cupón no encontrado");
        }
        cuponRepository.deleteById(id);
    }
}
