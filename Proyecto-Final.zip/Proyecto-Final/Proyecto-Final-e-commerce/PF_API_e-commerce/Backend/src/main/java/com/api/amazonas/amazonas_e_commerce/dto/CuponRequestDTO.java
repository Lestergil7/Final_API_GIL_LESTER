package com.api.amazonas.amazonas_e_commerce.dto;

import jakarta.validation.constraints.NotBlank;

public class CuponRequestDTO {
    @NotBlank
    private String nombre;
    private String descripcion;

    // Getters y setters
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
}
