package com.api.amazonas.amazonas_e_commerce.model;

public class Categoria {
    
}
